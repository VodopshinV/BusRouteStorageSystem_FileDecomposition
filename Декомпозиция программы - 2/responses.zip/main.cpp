#include"bus_manager.h"
#include <iostream>
#include <cassert>
using namespace std;

int main()
{
    return 0;
}